A supporting module for jplephem to handle data type 1


